read -p "           url/ip-------->" ip
clear
sleep 3
sudo nmap -Pn -sn --traceroute  $ip
read -p "                   ------------>entar"
payload.sh
