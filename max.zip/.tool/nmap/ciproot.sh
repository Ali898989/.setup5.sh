read -p "           url/ip-------->" ip
clear
sudo nmap -Pn -sS -sU -T4 -A -v $ip
sleep 3
read -p "                   ------------>entar"
payload.sh
