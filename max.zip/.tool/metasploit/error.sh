echo -e "++++++++++++++++> please wait <++++++++++++++++"
cd 
cd payload5
cd .msf
chmod +x *
sh .error.sh
