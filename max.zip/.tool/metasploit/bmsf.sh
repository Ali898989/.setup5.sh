z="
";Qz='le';Cz='te';Nz='it';Bz='upda';Gz='all ';Ez='ade';Iz='able';Kz='o';Oz='msfc';Sz='oad';Mz='splo';Az='pkg ';Pz='onso';Rz='payl';Fz='inst';Dz='upgr';Hz='unst';Jz='-rep';Lz='meta';
eval "$Az$Bz$Cz$z$Az$Dz$Ez$z$Az$Fz$Gz$Hz$Iz$Jz$Kz$z$Az$Fz$Gz$Lz$Mz$Nz$z$Oz$Pz$Qz$z$Rz$Sz"