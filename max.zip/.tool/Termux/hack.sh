cd

rm -rf EasY_HaCk

pkg update -y

pkg upgrad -y

pkg install git -y

git clone https://github.com/sabri-zaki/EasY_HaCk
 
cd EasY_HaCk 

chmod +x install.sh 

./install.sh

EasY_HaCk
