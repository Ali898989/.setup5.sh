f=$HOME/IPGeoLocation
if [ -d $f ];then
echo "It should be deleted first"
sleep 7
payload

else
cd
git clone https://github.com/maldevel/IPGeoLocation.git
cd IPGeoLocation
pip3 install -r requirements.txt --user
python ipgeolocation.py
fi
